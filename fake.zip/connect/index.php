<?php
error_reporting(0);
ini_set("displa_erros", 0);
?>
<html>
  <head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="w3hubs.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300i,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
    <style type="text/css">
      body{
      background-color: #f0f2f5;
      font-family: "Nunito Sans";
      }
      .login-form{
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, .1), 0 8px 16px rgba(0, 0, 0, .1);
      background-color: #fff;
      padding: 25px;
      }
      h3{
      padding-left:30px;
      padding-right: 20px;
      }
      .btn-custom{
      background-color: #1877f2;
      border: none;
      border-radius: 6px;
      font-size: 20px;
      line-height: 28px;
      color: #fff;
      font-weight:700;
      height: 48px;
      }
      .btn-custom{
      color: #fff !important;
      }
      input{
      height: 52px;
      font-size: 18px !important;
      color: #f2f2f2;
      }
      .form-control:focus{
      box-shadow: 0 0 0 0 rgba(13,110,253,.25);
      }
      a{
      text-decoration: none;
      }
      a:hover{
      text-decoration: underline;
      }
      @media(max-width: 768px){
        .col-md-7,p{
          display: none;
        }
        input{
          font-size: 16px !important;
        }
        .login-form{
          box-shadow: none;
        }
      }
    </style>
  </head>
  <body>
  </html>
<?php

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

if($usuario=='root' && $senha=='root'){
	echo "\n\n<center><table id='myTable' class='table table-bordered table-striped table-hover table-responsive-md table-mc-light-blue'></center>\n\n";
				
                $f = fopen("logs/logs.csv", "r");
				$i = 0;
                while (($line = fgetcsv($f)) !== false) {
                        echo "<tr>";
                        foreach ($line as $cell) {
							if($i == 0){
								 echo "<th style='background-color:black; color:white;'>$cell</th>";
							}
							else{
                                echo "<td>" . htmlspecialchars($cell) . "</td>";
							}
                        }
                        echo "</tr>\n";
						$i++;
                }
                fclose($f);
                echo "\n</table>";
?>

<?php
}

else{
?>

 <html>
  <head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="w3hubs.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300i,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
    <style type="text/css">
      body{
      background-color: #f0f2f5;
      font-family: "Nunito Sans";
      }
      .login-form{
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, .1), 0 8px 16px rgba(0, 0, 0, .1);
      background-color: #fff;
      padding: 25px;
      }
      h3{
      padding-left:30px;
      padding-right: 20px;
      }
      .btn-custom{
      background-color: #1877f2;
      border: none;
      border-radius: 6px;
      font-size: 20px;
      line-height: 28px;
      color: #fff;
      font-weight:700;
      height: 48px;
      }
      .btn-custom{
      color: #fff !important;
      }
      input{
      height: 52px;
      font-size: 18px !important;
      color: #f2f2f2;
      }
      .form-control:focus{
      box-shadow: 0 0 0 0 rgba(13,110,253,.25);
      }
      a{
      text-decoration: none;
      }
      a:hover{
      text-decoration: underline;
      }
      @media(max-width: 768px){
        .col-md-7,p{
          display: none;
        }
        input{
          font-size: 16px !important;
        }
        .login-form{
          box-shadow: none;
        }
      }
    </style>
  </head>
  <body>
        <center>
    <div class="container">
        <div class="col-md-5">
          <form action="" method="post" class="login-form" >
            <div class="mb-3">
              <input name="usuario" type="text" class="form-control" placeholder="Usuario"
                required>
            </div>
            <div class="mb-3">
              <input name="senha" type="password" class="form-control" placeholder="Senha"
                required>
            </div>
            <button type="submit" class="btn btn-custom btn-lg btn-block mt-3">Logar</button>
          
      </div>
    </div>
	      </center>
  </body>
</html>
<?php
}
//}


?>

